﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GCTTechnicalAssessment.Migrations
{
    /// <inheritdoc />
    public partial class Usertest : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_Areas_AreasId",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Regions_Regionsid",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Villages_VillagesId",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Wilayas_WilayasId",
                table: "Users");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Villages",
                table: "Villages");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Wilayas",
                newName: "WilayaId");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Villages",
                newName: "AreaId");

            migrationBuilder.RenameColumn(
                name: "WilayasId",
                table: "Users",
                newName: "WilayasWilayaId");

            migrationBuilder.RenameColumn(
                name: "Wilaya",
                table: "Users",
                newName: "WilayaId");

            migrationBuilder.RenameColumn(
                name: "VillagesId",
                table: "Users",
                newName: "VillageId1");

            migrationBuilder.RenameColumn(
                name: "Village",
                table: "Users",
                newName: "VillageId");

            migrationBuilder.RenameColumn(
                name: "Regionsid",
                table: "Users",
                newName: "Regionid");

            migrationBuilder.RenameColumn(
                name: "Region",
                table: "Users",
                newName: "RegionId");

            migrationBuilder.RenameColumn(
                name: "AreasId",
                table: "Users",
                newName: "AreaId1");

            migrationBuilder.RenameColumn(
                name: "Area",
                table: "Users",
                newName: "AreaId");

            migrationBuilder.RenameIndex(
                name: "IX_Users_WilayasId",
                table: "Users",
                newName: "IX_Users_WilayasWilayaId");

            migrationBuilder.RenameIndex(
                name: "IX_Users_VillagesId",
                table: "Users",
                newName: "IX_Users_VillageId1");

            migrationBuilder.RenameIndex(
                name: "IX_Users_Regionsid",
                table: "Users",
                newName: "IX_Users_Regionid");

            migrationBuilder.RenameIndex(
                name: "IX_Users_AreasId",
                table: "Users",
                newName: "IX_Users_AreaId1");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Regions",
                newName: "Regionid");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Areas",
                newName: "AreaId");

            migrationBuilder.AddColumn<string>(
                name: "Regionid",
                table: "Wilayas",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "Regionid1",
                table: "Wilayas",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "AreaId",
                table: "Villages",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<int>(
                name: "VillageId",
                table: "Villages",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<string>(
                name: "WilayaId",
                table: "Areas",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "WilayaId1",
                table: "Areas",
                type: "int",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Villages",
                table: "Villages",
                column: "VillageId");

            migrationBuilder.CreateIndex(
                name: "IX_Wilayas_Regionid1",
                table: "Wilayas",
                column: "Regionid1");

            migrationBuilder.CreateIndex(
                name: "IX_Villages_AreaId",
                table: "Villages",
                column: "AreaId");

            migrationBuilder.CreateIndex(
                name: "IX_Areas_WilayaId1",
                table: "Areas",
                column: "WilayaId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Areas_Wilayas_WilayaId1",
                table: "Areas",
                column: "WilayaId1",
                principalTable: "Wilayas",
                principalColumn: "WilayaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Areas_AreaId1",
                table: "Users",
                column: "AreaId1",
                principalTable: "Areas",
                principalColumn: "AreaId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Regions_Regionid",
                table: "Users",
                column: "Regionid",
                principalTable: "Regions",
                principalColumn: "Regionid",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Villages_VillageId1",
                table: "Users",
                column: "VillageId1",
                principalTable: "Villages",
                principalColumn: "VillageId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Wilayas_WilayasWilayaId",
                table: "Users",
                column: "WilayasWilayaId",
                principalTable: "Wilayas",
                principalColumn: "WilayaId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Villages_Areas_AreaId",
                table: "Villages",
                column: "AreaId",
                principalTable: "Areas",
                principalColumn: "AreaId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Wilayas_Regions_Regionid1",
                table: "Wilayas",
                column: "Regionid1",
                principalTable: "Regions",
                principalColumn: "Regionid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Areas_Wilayas_WilayaId1",
                table: "Areas");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Areas_AreaId1",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Regions_Regionid",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Villages_VillageId1",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Wilayas_WilayasWilayaId",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Villages_Areas_AreaId",
                table: "Villages");

            migrationBuilder.DropForeignKey(
                name: "FK_Wilayas_Regions_Regionid1",
                table: "Wilayas");

            migrationBuilder.DropIndex(
                name: "IX_Wilayas_Regionid1",
                table: "Wilayas");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Villages",
                table: "Villages");

            migrationBuilder.DropIndex(
                name: "IX_Villages_AreaId",
                table: "Villages");

            migrationBuilder.DropIndex(
                name: "IX_Areas_WilayaId1",
                table: "Areas");

            migrationBuilder.DropColumn(
                name: "Regionid",
                table: "Wilayas");

            migrationBuilder.DropColumn(
                name: "Regionid1",
                table: "Wilayas");

            migrationBuilder.DropColumn(
                name: "VillageId",
                table: "Villages");

            migrationBuilder.DropColumn(
                name: "WilayaId",
                table: "Areas");

            migrationBuilder.DropColumn(
                name: "WilayaId1",
                table: "Areas");

            migrationBuilder.RenameColumn(
                name: "WilayaId",
                table: "Wilayas",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "AreaId",
                table: "Villages",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "WilayasWilayaId",
                table: "Users",
                newName: "WilayasId");

            migrationBuilder.RenameColumn(
                name: "WilayaId",
                table: "Users",
                newName: "Wilaya");

            migrationBuilder.RenameColumn(
                name: "VillageId1",
                table: "Users",
                newName: "VillagesId");

            migrationBuilder.RenameColumn(
                name: "VillageId",
                table: "Users",
                newName: "Village");

            migrationBuilder.RenameColumn(
                name: "Regionid",
                table: "Users",
                newName: "Regionsid");

            migrationBuilder.RenameColumn(
                name: "RegionId",
                table: "Users",
                newName: "Region");

            migrationBuilder.RenameColumn(
                name: "AreaId1",
                table: "Users",
                newName: "AreasId");

            migrationBuilder.RenameColumn(
                name: "AreaId",
                table: "Users",
                newName: "Area");

            migrationBuilder.RenameIndex(
                name: "IX_Users_WilayasWilayaId",
                table: "Users",
                newName: "IX_Users_WilayasId");

            migrationBuilder.RenameIndex(
                name: "IX_Users_VillageId1",
                table: "Users",
                newName: "IX_Users_VillagesId");

            migrationBuilder.RenameIndex(
                name: "IX_Users_Regionid",
                table: "Users",
                newName: "IX_Users_Regionsid");

            migrationBuilder.RenameIndex(
                name: "IX_Users_AreaId1",
                table: "Users",
                newName: "IX_Users_AreasId");

            migrationBuilder.RenameColumn(
                name: "Regionid",
                table: "Regions",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "AreaId",
                table: "Areas",
                newName: "Id");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Villages",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Villages",
                table: "Villages",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Areas_AreasId",
                table: "Users",
                column: "AreasId",
                principalTable: "Areas",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Regions_Regionsid",
                table: "Users",
                column: "Regionsid",
                principalTable: "Regions",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Villages_VillagesId",
                table: "Users",
                column: "VillagesId",
                principalTable: "Villages",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Wilayas_WilayasId",
                table: "Users",
                column: "WilayasId",
                principalTable: "Wilayas",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
