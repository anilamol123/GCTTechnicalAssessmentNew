﻿namespace GCTTechnicalAssessment.Models
{
    public class Region
    {
        public int Regionid { get; set; }
        public string RegionName { get; set; }
    }
}
