﻿namespace GCTTechnicalAssessment.Models
{
    public class Village
    {
        public int VillageId { get; set; }
        public string VillageName { get; set; } = string.Empty;
        public int AreaId { get; set; }
        public Area? Area { get; set; }
    }
}
