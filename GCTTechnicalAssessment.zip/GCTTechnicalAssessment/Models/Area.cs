﻿using System.ComponentModel.DataAnnotations;

namespace GCTTechnicalAssessment.Models
{
    public class Area
    {
        [Key]
        public int AreaId { get; set; }
        [Required]
        public string AreaName { get; set; } = string.Empty;
        [Required]
        public int WilayaId { get; set; }
        public Wilaya? Wilaya { get; set; }
    }
}
