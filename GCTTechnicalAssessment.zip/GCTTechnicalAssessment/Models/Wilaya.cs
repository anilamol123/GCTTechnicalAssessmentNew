﻿using System.ComponentModel.DataAnnotations;

namespace GCTTechnicalAssessment.Models
{
    public class Wilaya
    {
        [Key]
        public int WilayaId { get; set; }
        [Required]
        public string WilayaName { get; set; } = string.Empty;
        [Required]
        public int RegionId { get; set; } 
        public Region? Region { get; set; }
    }
}
