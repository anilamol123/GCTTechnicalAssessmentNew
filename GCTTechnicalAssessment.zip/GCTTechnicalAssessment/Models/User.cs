﻿
using System.ComponentModel.DataAnnotations;

namespace GCTTechnicalAssessment.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        [Required]
        public string TypeofEntity { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Phonenumber { get; set; }
        [Required]
        public int RegionId { get; set; } 
        [Required]
        public  Region Region { get; set; }
        [Required]
        public int WilayaId { get; set; } 
        public Wilaya Wilayas { get; set; }
        [Required]
        public int AreaId { get; set; } 
        public Area Area { get; set; }
        [Required]
        public int VillageId { get; set; }
        public Village Village { get; set; }
        [Required]
        public string DetailsOfOpenDataExperience { get; set; }
        [Required]
        public string Remarks { get; set; }

    }
}
