using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using GCTTechnicalAssessment.DAL;
using GCTTechnicalAssessment.Models;

namespace GCTTechnicalAssessment.Pages.Users
{
    public class UserListModel : PageModel
    {
        public readonly AppDbContext _context;
        public UserListModel(AppDbContext context)
        {
            _context = context;
        }
        [BindProperty]
        public List<User> Users { get; set; } = new List<User>();
        public ActionResult OnGet()
        {
            Users = _context.Users.ToList();
            return Page();
        }
       
    }
}
