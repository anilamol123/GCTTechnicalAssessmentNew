using GCTTechnicalAssessment.DAL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GCTTechnicalAssessment.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GCTTechnicalAssessment.Pages.Users
{
    public class UserRegModel : PageModel
    {
        public readonly AppDbContext _context;
        public UserRegModel(AppDbContext context)
        {
            _context = context;
        }
       
        
        public List<SelectListItem> Regions { get; set; } = new();
        public List<SelectListItem> Wilayat { get; set; } = new();
        [BindProperty]
        public User User { get; set; } = new();
        [BindProperty]
        public Region RegionId { get; set; } = new ();
        public async Task OnGet()
        {

           await GetRegionsAsync();
        }
        private async Task GetRegionsAsync()
        {
            Regions = await _context.Regions.Select(r => new SelectListItem
            {
                Value = r.Regionid.ToString(),
                Text = r.RegionName
            }).ToListAsync();
        }
       
        public JsonResult OnGetWilaya(int regionId)
        {
            Wilayat =  _context.Wilayas.Where(w => w.RegionId == regionId)
                .Select(w => new SelectListItem
                {
                    Value = w.WilayaId.ToString(),
                    Text = w.WilayaName
                })
                .ToList();
            return new JsonResult(Wilayat);
        }
        private async Task OnGetAreaAsync(int wilayatId)
        {
            var areas = await _context.Areas.Where(a => a.WilayaId == wilayatId)
                .Select(a => new SelectListItem
                {
                    Value = a.AreaId.ToString(),
                    Text = a.AreaName
                })
                .ToListAsync();
        }
        private async Task OnGetVillageAsync(int areaId)
        {
            var village = await _context.Villages.Where(v => v.AreaId == areaId)
                .Select(v => new SelectListItem
                {
                    Value = v.VillageId.ToString(),
                    Text = v.VillageName
                })
                .ToListAsync();
        }
        public ActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
               
               // Regions = _context.Regions.ToList();
               
                return Page();
            }
            _context.Users.Add(User);
            _context.SaveChanges();
            return RedirectToPage("/Users/UserReg");
        }
       
    }
}
