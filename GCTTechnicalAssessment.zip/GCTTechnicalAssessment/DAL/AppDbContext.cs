﻿using Microsoft.EntityFrameworkCore;

namespace GCTTechnicalAssessment.DAL
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options):base(options)
        {
        }
        public DbSet<Models.User> Users { get; set; }
        public DbSet<Models.Wilaya> Wilayas { get; set; }
        public DbSet<Models.Area> Areas { get; set; }
        public DbSet<Models.Village> Villages { get; set; }
        public DbSet<Models.Region> Regions { get; set; }
    }
}
